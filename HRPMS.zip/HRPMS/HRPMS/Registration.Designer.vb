﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Registration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpEmployee = New System.Windows.Forms.GroupBox()
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker()
        Me.lblDOB = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.radFemale = New System.Windows.Forms.RadioButton()
        Me.radMale = New System.Windows.Forms.RadioButton()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtNumber = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtNaID = New System.Windows.Forms.TextBox()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.lblPnumber = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblNatID = New System.Windows.Forms.Label()
        Me.lblSex = New System.Windows.Forms.Label()
        Me.lblSurname = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.grpEmployee.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpEmployee
        '
        Me.grpEmployee.Controls.Add(Me.dtpDOB)
        Me.grpEmployee.Controls.Add(Me.lblDOB)
        Me.grpEmployee.Controls.Add(Me.btnClose)
        Me.grpEmployee.Controls.Add(Me.btnReset)
        Me.grpEmployee.Controls.Add(Me.btnSave)
        Me.grpEmployee.Controls.Add(Me.radFemale)
        Me.grpEmployee.Controls.Add(Me.radMale)
        Me.grpEmployee.Controls.Add(Me.txtEmail)
        Me.grpEmployee.Controls.Add(Me.txtNumber)
        Me.grpEmployee.Controls.Add(Me.txtAddress)
        Me.grpEmployee.Controls.Add(Me.txtNaID)
        Me.grpEmployee.Controls.Add(Me.txtSurname)
        Me.grpEmployee.Controls.Add(Me.txtName)
        Me.grpEmployee.Controls.Add(Me.txtID)
        Me.grpEmployee.Controls.Add(Me.lblPnumber)
        Me.grpEmployee.Controls.Add(Me.lblEmail)
        Me.grpEmployee.Controls.Add(Me.lblAddress)
        Me.grpEmployee.Controls.Add(Me.lblNatID)
        Me.grpEmployee.Controls.Add(Me.lblSex)
        Me.grpEmployee.Controls.Add(Me.lblSurname)
        Me.grpEmployee.Controls.Add(Me.lblName)
        Me.grpEmployee.Controls.Add(Me.lblID)
        Me.grpEmployee.Location = New System.Drawing.Point(12, 12)
        Me.grpEmployee.Name = "grpEmployee"
        Me.grpEmployee.Size = New System.Drawing.Size(355, 364)
        Me.grpEmployee.TabIndex = 0
        Me.grpEmployee.TabStop = False
        Me.grpEmployee.Text = "EMPLOYEE REGISTRATION"
        '
        'dtpDOB
        '
        Me.dtpDOB.Location = New System.Drawing.Point(161, 108)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.Size = New System.Drawing.Size(188, 20)
        Me.dtpDOB.TabIndex = 22
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Location = New System.Drawing.Point(15, 113)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(30, 13)
        Me.lblDOB.TabIndex = 21
        Me.lblDOB.Text = "DOB"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(279, 318)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(55, 23)
        Me.btnClose.TabIndex = 20
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(161, 319)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(59, 23)
        Me.btnReset.TabIndex = 19
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(29, 318)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(61, 23)
        Me.btnSave.TabIndex = 18
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'radFemale
        '
        Me.radFemale.AutoSize = True
        Me.radFemale.Location = New System.Drawing.Point(215, 133)
        Me.radFemale.Name = "radFemale"
        Me.radFemale.Size = New System.Drawing.Size(59, 17)
        Me.radFemale.TabIndex = 17
        Me.radFemale.TabStop = True
        Me.radFemale.Text = "Female"
        Me.radFemale.UseVisualStyleBackColor = True
        '
        'radMale
        '
        Me.radMale.AutoSize = True
        Me.radMale.Location = New System.Drawing.Point(161, 135)
        Me.radMale.Name = "radMale"
        Me.radMale.Size = New System.Drawing.Size(48, 17)
        Me.radMale.TabIndex = 16
        Me.radMale.TabStop = True
        Me.radMale.Text = "Male"
        Me.radMale.UseVisualStyleBackColor = True
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(161, 265)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(113, 20)
        Me.txtEmail.TabIndex = 15
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(161, 228)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(113, 20)
        Me.txtNumber.TabIndex = 14
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(161, 187)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(113, 20)
        Me.txtAddress.TabIndex = 13
        '
        'txtNaID
        '
        Me.txtNaID.Location = New System.Drawing.Point(161, 160)
        Me.txtNaID.Name = "txtNaID"
        Me.txtNaID.Size = New System.Drawing.Size(113, 20)
        Me.txtNaID.TabIndex = 12
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(161, 81)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(113, 20)
        Me.txtSurname.TabIndex = 10
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(161, 49)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(113, 20)
        Me.txtName.TabIndex = 9
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(161, 17)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(113, 20)
        Me.txtID.TabIndex = 8
        '
        'lblPnumber
        '
        Me.lblPnumber.AutoSize = True
        Me.lblPnumber.Location = New System.Drawing.Point(12, 236)
        Me.lblPnumber.Name = "lblPnumber"
        Me.lblPnumber.Size = New System.Drawing.Size(78, 13)
        Me.lblPnumber.TabIndex = 7
        Me.lblPnumber.Text = "Phone Number"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(12, 273)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(32, 13)
        Me.lblEmail.TabIndex = 6
        Me.lblEmail.Text = "Email"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(15, 199)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblAddress.TabIndex = 5
        Me.lblAddress.Text = "Address"
        '
        'lblNatID
        '
        Me.lblNatID.AutoSize = True
        Me.lblNatID.Location = New System.Drawing.Point(12, 167)
        Me.lblNatID.Name = "lblNatID"
        Me.lblNatID.Size = New System.Drawing.Size(63, 13)
        Me.lblNatID.TabIndex = 4
        Me.lblNatID.Text = "National I.D"
        '
        'lblSex
        '
        Me.lblSex.AutoSize = True
        Me.lblSex.Location = New System.Drawing.Point(12, 135)
        Me.lblSex.Name = "lblSex"
        Me.lblSex.Size = New System.Drawing.Size(25, 13)
        Me.lblSex.TabIndex = 3
        Me.lblSex.Text = "Sex"
        '
        'lblSurname
        '
        Me.lblSurname.AutoSize = True
        Me.lblSurname.Location = New System.Drawing.Point(15, 88)
        Me.lblSurname.Name = "lblSurname"
        Me.lblSurname.Size = New System.Drawing.Size(49, 13)
        Me.lblSurname.TabIndex = 2
        Me.lblSurname.Text = "Surname"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(15, 56)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(35, 13)
        Me.lblName.TabIndex = 1
        Me.lblName.Text = "Name"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(12, 24)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(67, 13)
        Me.lblID.TabIndex = 0
        Me.lblID.Text = "Employee ID"
        '
        'Registration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(379, 402)
        Me.Controls.Add(Me.grpEmployee)
        Me.Name = "Registration"
        Me.Text = "Registration"
        Me.grpEmployee.ResumeLayout(False)
        Me.grpEmployee.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpEmployee As System.Windows.Forms.GroupBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents radFemale As System.Windows.Forms.RadioButton
    Friend WithEvents radMale As System.Windows.Forms.RadioButton
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtNaID As System.Windows.Forms.TextBox
    Friend WithEvents txtSurname As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents lblPnumber As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblNatID As System.Windows.Forms.Label
    Friend WithEvents lblSex As System.Windows.Forms.Label
    Friend WithEvents lblSurname As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents dtpDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDOB As System.Windows.Forms.Label
End Class
