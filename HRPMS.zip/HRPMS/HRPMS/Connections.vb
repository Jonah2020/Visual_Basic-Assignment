﻿Imports System.Convert
Imports MySql.Data.MySqlClient
Public Module HRPMS
    Public Sub Connection()
        Dim connectionString As String
        Dim hrpConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;password=stan;database=hrp_db"
        hrpConn.ConnectionString = connectionString
        Try
            hrpConn.Open()

        Catch ex As MySqlException
            MsgBox(ex.Message)w

        End Try
    End Sub
    Function HRConnection() As MySqlConnection
        Dim connectionString As String
        Dim hrpConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;password=stan;database=hrp_db"
        hrpConn.ConnectionString = connectionString
        Try
            hrpConn.Open()
            MsgBox("Connected")
        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try
        Return hrpConn
    End Function
   
    Public Sub SaveData()

        Dim employ_id As String
        Dim name As String
        Dim surname As String
        Dim sex As String
        Dim email As String
        Dim nat_id As String
        Dim address As String
        Dim pnumber As String
        Dim dob As String


        Dim cmd As New MySqlCommand
        Dim sqlString As String


        If .radmale.Checked Then
            sex = "Male"
        Else
            sex = "Female"
        End If
         
        sqlString = "INSERT INTO animal_owner VALUES('" & employ_id & "','" &
            name & "','" & surname & "','" & email & "','" & sex & "','" & nat_id & "'," & address & "," & bathing & ","
           " & pnumber & ",'" & dob & "')"

        With cmd
            .Connection = HRConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            .ExecuteNonQuery()
        End With
        MsgBox("Data Saved")


    End Sub




End Module
