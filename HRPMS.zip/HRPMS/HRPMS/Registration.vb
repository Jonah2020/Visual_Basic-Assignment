﻿Public Class Registration

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        txtID.Clear()
        txtName.Clear()
        txtSurname.Clear()
        txtNaID.Clear()
        txtAddress.Clear()
        txtNumber.Clear()
        txtEmail.Clear()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If txtID.Text = "" Then
            MsgBox("Employee ID cannot be empty")
            txtID.Focus()

        End If

        If txtName.Text = "" Then
            MsgBox("Name cannot be empty")
            txtName.Focus()

        End If

        If txtSurname.Text = "" Then
            MsgBox("Surname cannot be empty")
            txtSurname.Focus()

        End If

        If radMale.Checked = False And radFemale.Checked = False Then


            MsgBox("Please check Male or Female")

        End If

        If txtNaID.Text = "" Then
            MsgBox("Nationa ID cannot be empty")
            txtNaID.Focus()

        End If

        If txtAddress.Text = "" Then
            MsgBox("Address cannot be empty")
            txtAddress.Focus()

        End If

        If txtNumber.Text = "" Then
            MsgBox("Phone Number cannot be empty")
            txtNumber.Focus()

        End If

        If txtEmail.Text = "" Then
            MsgBox("Email cannot be empty")
            txtEmail.Focus()

        End If
        
    End Sub

    Private Sub Registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class